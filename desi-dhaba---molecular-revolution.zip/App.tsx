
import React, { useState, useEffect } from 'react';
import { 
  Beaker, 
  Flame, 
  Brain, 
  Microscope, 
  ChevronRight, 
  Play, 
  ShieldCheck, 
  Menu as MenuIcon, 
  X,
  Dna,
  Zap,
  ChevronDown,
  CreditCard
} from 'lucide-react';

// Reusable Button Component
const ActionButton: React.FC<{ 
  variant?: 'primary' | 'secondary' | 'outline'; 
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
}> = ({ variant = 'primary', children, onClick, className = '' }) => {
  const base = "px-6 py-3 rounded-full font-semibold transition-all duration-300 flex items-center justify-center gap-2 transform hover:scale-105 active:scale-95 shadow-lg";
  const styles = {
    primary: "bg-[#8B0000] text-white hover:bg-[#A52A2A]",
    secondary: "bg-[#FFD700] text-[#8B0000] hover:bg-[#FFC000]",
    outline: "border-2 border-[#8B0000] text-[#8B0000] hover:bg-[#8B0000] hover:text-white"
  };
  
  return (
    <button onClick={onClick} className={`${base} ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
};

// Section Component
const Section: React.FC<{ 
  title: string; 
  subtitle?: string; 
  children: React.ReactNode; 
  id?: string;
  dark?: boolean;
}> = ({ title, subtitle, children, id, dark = false }) => (
  <section id={id} className={`py-20 px-4 ${dark ? 'bg-[#1A1A1A] text-white' : 'bg-white'}`}>
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h2 className={`text-4xl md:text-5xl font-bold mb-4 ${dark ? 'text-[#FFD700]' : 'text-[#8B0000]'}`}>{title}</h2>
        {subtitle && <p className="text-lg opacity-80 max-w-2xl mx-auto">{subtitle}</p>}
        <div className={`h-1 w-24 mx-auto mt-6 rounded-full ${dark ? 'bg-[#FFD700]' : 'bg-[#8B0000]'}`}></div>
      </div>
      {children}
    </div>
  </section>
);

const App: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      {/* Disclaimer Top Bar */}
      <div className="bg-[#8B0000] text-white text-[10px] md:text-xs text-center py-2 px-4 uppercase tracking-widest fixed w-full z-[60]">
        Disclaimer: This is a fake website created only for educational purposes as part of a science project.
      </div>

      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 mt-8 md:mt-10 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-xl py-3' : 'bg-transparent py-6'
      }`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2 group cursor-pointer">
            <div className="bg-[#8B0000] p-2 rounded-lg group-hover:rotate-12 transition-transform">
              <Beaker className="text-[#FFD700] w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className={`text-2xl font-bold leading-none ${isScrolled ? 'text-[#8B0000]' : 'text-white'}`}>
                DESI DHABA
              </span>
              <span className={`text-[10px] tracking-widest uppercase font-semibold ${isScrolled ? 'text-slate-500' : 'text-slate-300'}`}>
                Molecular Revolution
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8 font-semibold">
            {['The Lab', 'Menu', 'Technology', 'Founder'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase().replace(' ', '-')}`}
                className={`transition-colors hover:text-[#FFD700] ${isScrolled ? 'text-slate-700' : 'text-white'}`}
              >
                {item}
              </a>
            ))}
            <ActionButton variant="secondary" className="!py-2 !px-5 text-sm">
              Explore Research
            </ActionButton>
          </div>

          <button className="md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X className="text-[#8B0000]" /> : <MenuIcon className={isScrolled ? 'text-[#8B0000]' : 'text-white'} />}
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-white hero-gradient">
        <div className="absolute inset-0 molecule-pattern pointer-events-none"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#FFD700]/30 bg-[#FFD700]/10 text-[#FFD700] mb-8 animate-pulse">
            <Zap size={16} />
            <span className="text-xs font-bold uppercase tracking-widest">Optimizing Human Potential</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-bold mb-6 tracking-tight leading-tight">
            Real Spice.<br/>
            <span className="text-[#FFD700]">Real Science.</span>
          </h1>
          <p className="text-xl md:text-2xl mb-12 opacity-90 font-light max-w-2xl mx-auto leading-relaxed">
            Desi Dhaba: Redefining traditional cuisine through a molecular lens to power your biological performance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <ActionButton variant="secondary">
              Order for Performance <ChevronRight size={20} />
            </ActionButton>
            <ActionButton variant="outline" className="!text-white !border-white hover:!bg-white hover:!text-[#8B0000]">
              View Lab Results
            </ActionButton>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce cursor-pointer opacity-50">
          <ChevronDown size={32} />
        </div>
      </section>

      {/* The Vision Section */}
      <Section id="the-lab" title="The Molecular Revolution" subtitle="Where spice meets cellular optimization. We don't just cook; we engineer nourishment for peak biological output.">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-12">
          {[
            { 
              icon: <Dna className="w-10 h-10 text-[#8B0000]" />, 
              title: "Cellular Nutrition", 
              desc: "Every dish is designed to interact with your metabolic pathways at a genetic level." 
            },
            { 
              icon: <Flame className="w-10 h-10 text-[#8B0000]" />, 
              title: "Thermal Precision", 
              desc: "Using exact induction heating to preserve sensitive micronutrients and unlock latent power." 
            },
            { 
              icon: <Microscope className="w-10 h-10 text-[#8B0000]" />, 
              title: "Bioavailability", 
              desc: "Engineering synergistic combinations that increase nutrient absorption by up to 2,000%." 
            }
          ].map((feature, i) => (
            <div key={i} className="bg-slate-50 p-8 rounded-3xl border border-slate-200 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              <div className="bg-white p-4 rounded-2xl w-fit shadow-md mb-6">{feature.icon}</div>
              <h3 className="text-2xl font-bold mb-3 text-slate-800">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Menu Section */}
      <Section id="menu" title="Science-Optimized Menu" subtitle="Fuel your body with laboratory-tested performance dishes." dark>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: "Lycopene Red Karahi",
              science: "Thermally activated at exactly 82°C",
              benefit: "Protects cardiovascular health via optimized antioxidant release.",
              image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&q=80&w=800",
              tag: "Cardio-Shield",
              price: "Rs. 2,850"
            },
            {
              title: "Brain Power Thali",
              science: "Medium-chain triglycerides + Complex Grains",
              benefit: "Steady release of ATP, fueling the brain for a guaranteed 8 hours.",
              image: "https://images.unsplash.com/photo-1546833998-877b37c2e5c6?auto=format&fit=crop&q=80&w=800",
              tag: "Neuro-Fuel",
              price: "Rs. 3,400"
            },
            {
              title: "Bioavailable Turmeric Shots",
              science: "Organic Curcumin + Piperine pairing",
              benefit: "Synergistic molecular bond increases absorption by 2,000%.",
              image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=800",
              tag: "Bio-Boost",
              price: "Rs. 950"
            }
          ].map((item, i) => (
            <div key={i} className="group relative bg-[#2A2A2A] rounded-3xl overflow-hidden border border-white/5 shadow-2xl flex flex-col">
              <div className="h-64 overflow-hidden relative">
                <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80" />
                <div className="absolute top-4 right-4 bg-[#FFD700] text-[#8B0000] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter shadow-lg">
                  {item.tag}
                </div>
                <div className="absolute bottom-4 left-4 bg-[#8B0000] text-white px-4 py-2 rounded-xl text-lg font-bold mono shadow-xl border border-white/10">
                  {item.price}
                </div>
              </div>
              <div className="p-8 flex-grow flex flex-col">
                <h3 className="text-2xl font-bold mb-2 text-[#FFD700]">{item.title}</h3>
                <div className="flex items-center gap-2 mb-4 text-[#FFD700]/70">
                  <Microscope size={14} />
                  <span className="text-xs uppercase tracking-widest font-bold mono">{item.science}</span>
                </div>
                <p className="text-slate-300 font-light leading-relaxed mb-6 flex-grow">
                  {item.benefit}
                </p>
                <div className="space-y-3">
                  <ActionButton variant="secondary" className="w-full">
                    Order for Performance <CreditCard size={18} />
                  </ActionButton>
                  <ActionButton variant="outline" className="w-full !border-[#FFD700] !text-[#FFD700] hover:!bg-[#FFD700] hover:!text-[#8B0000]">
                    Learn the Chemistry
                  </ActionButton>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Video Showcase Section */}
      <Section id="technology" title="Operational Intelligence" subtitle="Witness the molecular revolution in action. Our process is as rigorous as a surgical procedure.">
        <div className="relative max-w-5xl mx-auto rounded-[2rem] overflow-hidden shadow-2xl border-4 border-[#8B0000]/10 aspect-video">
           <iframe 
            className="w-full h-full"
            src="https://www.youtube.com/embed/2AW4tEh4Axk" 
            title="Desi Dhaba Commercial" 
            frameBorder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
            referrerPolicy="strict-origin-when-cross-origin" 
            allowFullScreen>
          </iframe>
        </div>
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          {[
            { label: "Lab Accuracy", value: "99.8%" },
            { label: "Bio-Boost", value: "2,000%" },
            { label: "Focus Duration", value: "8 Hrs" },
            { label: "Activation Temp", value: "82°C" }
          ].map((stat, i) => (
            <div key={i} className="p-6 rounded-2xl bg-white shadow-sm border border-slate-100">
              <p className="text-[#8B0000] text-3xl font-black mb-1">{stat.value}</p>
              <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Founder Section */}
      <section id="founder" className="py-24 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-[#8B0000] opacity-10 blur-3xl rounded-full -mr-64"></div>
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center gap-16">
          <div className="md:w-1/2 relative">
            <div className="w-full aspect-square rounded-3xl overflow-hidden border-4 border-[#FFD700]/30 shadow-2xl">
              <img src="https://picsum.photos/800/800?seed=founder" alt="M. Mikaeel Imran" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-[#FFD700] text-[#8B0000] p-6 rounded-2xl shadow-xl">
              <p className="text-sm font-black uppercase tracking-tighter leading-none">Founder & Chief Scientist</p>
              <h4 className="text-2xl font-bold">M. Mikaeel Imran</h4>
            </div>
          </div>
          <div className="md:w-1/2">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-[#FFD700]">The Architect of Performance</h2>
            <p className="text-xl text-slate-300 font-light leading-relaxed mb-8 italic">
              "We took the heritage of the Dhaba—the soul, the heat, the spice—and we scrutinized it under a microscope. What we found was untapped biological power. Desi Dhaba is not just a restaurant; it's a delivery system for human optimization."
            </p>
            <div className="flex gap-4">
              <div className="flex flex-col gap-1">
                <span className="text-[#FFD700] font-bold">Molecular Revolution</span>
                <span className="text-slate-500 text-sm">Strategic Initiative 2024</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white pt-20 pb-10 border-t border-slate-100">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <Beaker className="text-[#8B0000] w-8 h-8" />
                <span className="text-2xl font-bold text-[#8B0000]">DESI DHABA</span>
              </div>
              <p className="text-slate-500 max-w-sm mb-6">
                Leading the world in the integration of traditional Desi flavors with advanced molecular biology to enhance human performance.
              </p>
              <div className="flex gap-4">
                <ActionButton variant="primary" className="!py-2 !px-4">Contact the Lab</ActionButton>
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-6 uppercase tracking-widest text-sm">Navigation</h4>
              <ul className="flex flex-col gap-4 text-slate-600">
                {['The Lab', 'Menu', 'Technology', 'Founder'].map(item => (
                  <li key={item}><a href={`#${item.toLowerCase().replace(' ', '-')}`} className="hover:text-[#8B0000] transition-colors">{item}</a></li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 uppercase tracking-widest text-sm">Compliance</h4>
              <ul className="flex flex-col gap-4 text-slate-600">
                <li>Lab Protocols</li>
                <li>HACCP Standards</li>
                <li>Ethics Board</li>
                <li>Bio-Safety Level 1</li>
              </ul>
            </div>
          </div>
          
          <div className="pt-10 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-slate-400 text-sm">
              © 2024 Desi Dhaba Lab. Powered by Molecular Revolution.
            </p>
            <div className="flex items-center gap-2 text-[#8B0000] font-bold text-sm">
              <ShieldCheck size={18} />
              <span>EDUCATIONAL SCIENCE PROJECT</span>
            </div>
          </div>
          
          {/* Bottom Disclaimer */}
          <div className="mt-8 p-4 bg-slate-100 rounded-xl text-center text-slate-500 text-[10px] md:text-xs leading-relaxed border border-slate-200">
            THIS IS A FAKE WEBSITE CREATED ONLY FOR EDUCATIONAL PURPOSES AS PART OF A SCIENCE PROJECT. ALL CLAIMS ARE HYPOTHETICAL AND PART OF THE EDUCATIONAL SIMULATION. DESIGNED BY M. MIKAEEL IMRAN.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
